package com.ebo_host.channel_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChannelManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChannelManagerApplication.class, args);
	}

}
