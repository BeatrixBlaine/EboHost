package com.ebo_host.channel_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChannelManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
